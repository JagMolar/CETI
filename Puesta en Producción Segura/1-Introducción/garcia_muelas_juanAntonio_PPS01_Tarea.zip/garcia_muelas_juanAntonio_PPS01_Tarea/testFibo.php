<?php
require './tests/fibo.php';
// Importa el archivo con la función a probar
use PHPUnit\Framework\TestCase; 
// utiliza la librería con PHPUnit

// crea una clase que hereda de TestCase
class testFibo extends TestCase
{
    
    // crea un método para realizar las pruebas
    public function testFibonacci3()
    {
        $secuencia = fibonacci(3);
        $this->assertEquals([0, 1, 1], $secuencia);
        // comprueba que el resultado esperado es igual al obtenido
    }

    public function testFibonacci5()
    {
        $secuencia = fibonacci(5);
        $this->assertEquals([0, 1, 1, 2, 3], $secuencia);
    }

    /*
    public function testFibonacciNegativo()
    {
        $this->expectException(Exception::class);
        fibonacci(-1);
    } */
}

?>
