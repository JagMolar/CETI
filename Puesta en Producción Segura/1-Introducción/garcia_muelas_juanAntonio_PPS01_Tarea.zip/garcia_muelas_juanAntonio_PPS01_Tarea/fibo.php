<?php 
// Juan Antonio García Muelas
/**
 * Tarea PPS01.
 * Generar secuencia Fibonacci en PHP
 */

function fibonacci($n) {
    /* Si el valor indicado es menor o igual a 1, 
    devolvemos un array con el parámetro */
    if ($n <= 1) {
      return [$n];
    }
  
    // Inicializamos dos variables para almacenar el comienzo de la secuencia
    $a = 0; // Primer valor
    $b = 1; // Segundo valor
    $secuencia = [$a, $b];

    try {
      // Generamos nuevos valores con un bucle for
      for ($i = 2; $i < $n; $i++) {
        // Calculamos el siguiente valor
        $c = $a + $b;
    
        // Asignamos los nuevos valores
        $a = $b;
        $b = $c;
    
        // Añadimos nuevo valor a la secuencia
        array_push($secuencia, $c);
      }
    } catch (Exception $e) {
      //Si el valor es erróneo lo devolvemos vacío
      return [];
    }  
    // Devolvemos la secuencia
      return $secuencia;
  }
  
  // Indicamos el número  de valores a generar
  $n = 6;
  $secuencia = fibonacci($n);
  // Mostramos los valores
  if ($n >= 0) {
    echo implode(", ", $secuencia);
  } else {
    echo "El valor de n debe ser mayor o igual a 1";
  }

?>

